//
// Academic Student License -- for use by students to meet course
// requirements and perform academic research at degree granting
// institutions only.  Not for government, commercial, or other
// organizational use.
// File: rescale.cpp
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 05-Oct-2017 01:25:03
//

// Include Files
#include "rt_nonfinite.h"
#include "getLaws.h"
#include "rescale.h"
#include "getLaws_emxutil.h"

// Function Definitions

//
// RESCALE Rescale data into the range [0,1].
//    RESCALE(I) rescales the array I so that all elements fall in the range
//    [0,1]. The output is double precision.
//
//    See also RESCALE_RANGE.
//
// JC
// Arguments    : emxArray_real_T *I
// Return Type  : void
//
void rescale(emxArray_real_T *I)
{
  int ixstart;
  int n;
  double mtmp;
  int ix;
  boolean_T exitg1;
  double b_mtmp;
  double c_mtmp;
  int i2;

  //  Convert input to double precision
  //  Make sure the data can be rescaled with the current machine precision
  ixstart = 1;
  n = I->size[0] * I->size[1];
  mtmp = I->data[0];
  if (I->size[0] * I->size[1] > 1) {
    if (rtIsNaN(I->data[0])) {
      ix = 2;
      exitg1 = false;
      while ((!exitg1) && (ix <= n)) {
        ixstart = ix;
        if (!rtIsNaN(I->data[ix - 1])) {
          mtmp = I->data[ix - 1];
          exitg1 = true;
        } else {
          ix++;
        }
      }
    }

    if (ixstart < I->size[0] * I->size[1]) {
      while (ixstart + 1 <= n) {
        if (I->data[ixstart] > mtmp) {
          mtmp = I->data[ixstart];
        }

        ixstart++;
      }
    }
  }

  ixstart = 1;
  n = I->size[0] * I->size[1];
  b_mtmp = I->data[0];
  if (I->size[0] * I->size[1] > 1) {
    if (rtIsNaN(I->data[0])) {
      ix = 2;
      exitg1 = false;
      while ((!exitg1) && (ix <= n)) {
        ixstart = ix;
        if (!rtIsNaN(I->data[ix - 1])) {
          b_mtmp = I->data[ix - 1];
          exitg1 = true;
        } else {
          ix++;
        }
      }
    }

    if (ixstart < I->size[0] * I->size[1]) {
      while (ixstart + 1 <= n) {
        if (I->data[ixstart] < b_mtmp) {
          b_mtmp = I->data[ixstart];
        }

        ixstart++;
      }
    }
  }

  if (mtmp - b_mtmp > 2.2204460492503131E-16) {
    //  Iout = (I- min(I)) / range(I)
    ixstart = 1;
    n = I->size[0] * I->size[1];
    mtmp = I->data[0];
    if (I->size[0] * I->size[1] > 1) {
      if (rtIsNaN(I->data[0])) {
        ix = 2;
        exitg1 = false;
        while ((!exitg1) && (ix <= n)) {
          ixstart = ix;
          if (!rtIsNaN(I->data[ix - 1])) {
            mtmp = I->data[ix - 1];
            exitg1 = true;
          } else {
            ix++;
          }
        }
      }

      if (ixstart < I->size[0] * I->size[1]) {
        while (ixstart + 1 <= n) {
          if (I->data[ixstart] < mtmp) {
            mtmp = I->data[ixstart];
          }

          ixstart++;
        }
      }
    }

    ixstart = 1;
    n = I->size[0] * I->size[1];
    b_mtmp = I->data[0];
    if (I->size[0] * I->size[1] > 1) {
      if (rtIsNaN(I->data[0])) {
        ix = 2;
        exitg1 = false;
        while ((!exitg1) && (ix <= n)) {
          ixstart = ix;
          if (!rtIsNaN(I->data[ix - 1])) {
            b_mtmp = I->data[ix - 1];
            exitg1 = true;
          } else {
            ix++;
          }
        }
      }

      if (ixstart < I->size[0] * I->size[1]) {
        while (ixstart + 1 <= n) {
          if (I->data[ixstart] > b_mtmp) {
            b_mtmp = I->data[ixstart];
          }

          ixstart++;
        }
      }
    }

    ixstart = 1;
    n = I->size[0] * I->size[1];
    c_mtmp = I->data[0];
    if (I->size[0] * I->size[1] > 1) {
      if (rtIsNaN(I->data[0])) {
        ix = 2;
        exitg1 = false;
        while ((!exitg1) && (ix <= n)) {
          ixstart = ix;
          if (!rtIsNaN(I->data[ix - 1])) {
            c_mtmp = I->data[ix - 1];
            exitg1 = true;
          } else {
            ix++;
          }
        }
      }

      if (ixstart < I->size[0] * I->size[1]) {
        while (ixstart + 1 <= n) {
          if (I->data[ixstart] < c_mtmp) {
            c_mtmp = I->data[ixstart];
          }

          ixstart++;
        }
      }
    }

    b_mtmp -= c_mtmp;
    ixstart = I->size[0] * I->size[1];
    emxEnsureCapacity((emxArray__common *)I, ixstart, sizeof(double));
    n = I->size[1];
    for (ixstart = 0; ixstart < n; ixstart++) {
      ix = I->size[0];
      for (i2 = 0; i2 < ix; i2++) {
        I->data[i2 + I->size[0] * ixstart] = (I->data[i2 + I->size[0] * ixstart]
          - mtmp) / b_mtmp;
      }
    }
  }
}

//
// File trailer for rescale.cpp
//
// [EOF]
//
