//
// Academic Student License -- for use by students to meet course
// requirements and perform academic research at degree granting
// institutions only.  Not for government, commercial, or other
// organizational use.
// File: getLaws_terminate.cpp
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 05-Oct-2017 01:25:03
//

// Include Files
#include "rt_nonfinite.h"
#include "getLaws.h"
#include "getLaws_terminate.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void getLaws_terminate()
{
  // (no terminate code required)
}

//
// File trailer for getLaws_terminate.cpp
//
// [EOF]
//
