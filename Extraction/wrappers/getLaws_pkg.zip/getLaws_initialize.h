//
// Academic Student License -- for use by students to meet course
// requirements and perform academic research at degree granting
// institutions only.  Not for government, commercial, or other
// organizational use.
// File: getLaws_initialize.h
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 05-Oct-2017 01:25:03
//
#ifndef GETLAWS_INITIALIZE_H
#define GETLAWS_INITIALIZE_H

// Include Files
#include <cmath>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "getLaws_types.h"

// Function Declarations
extern void getLaws_initialize();

#endif

//
// File trailer for getLaws_initialize.h
//
// [EOF]
//
