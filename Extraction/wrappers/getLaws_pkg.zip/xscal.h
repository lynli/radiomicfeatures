//
// Academic Student License -- for use by students to meet course
// requirements and perform academic research at degree granting
// institutions only.  Not for government, commercial, or other
// organizational use.
// File: xscal.h
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 05-Oct-2017 01:25:03
//
#ifndef XSCAL_H
#define XSCAL_H

// Include Files
#include <cmath>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "getLaws_types.h"

// Function Declarations
extern void xscal(double a, double x[25], int ix0);

#endif

//
// File trailer for xscal.h
//
// [EOF]
//
