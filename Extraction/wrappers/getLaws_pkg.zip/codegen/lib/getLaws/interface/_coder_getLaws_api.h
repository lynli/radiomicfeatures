/*
 * Academic Student License -- for use by students to meet course
 * requirements and perform academic research at degree granting
 * institutions only.  Not for government, commercial, or other
 * organizational use.
 * File: _coder_getLaws_api.h
 *
 * MATLAB Coder version            : 3.3
 * C/C++ source code generated on  : 05-Oct-2017 01:25:03
 */

#ifndef _CODER_GETLAWS_API_H
#define _CODER_GETLAWS_API_H

/* Include Files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include <stddef.h>
#include <stdlib.h>
#include "_coder_getLaws_api.h"

/* Type Definitions */
#ifndef struct_emxArray_real_T
#define struct_emxArray_real_T

struct emxArray_real_T
{
  real_T *data;
  int32_T *size;
  int32_T allocatedSize;
  int32_T numDimensions;
  boolean_T canFreeData;
};

#endif                                 /*struct_emxArray_real_T*/

#ifndef typedef_emxArray_real_T
#define typedef_emxArray_real_T

typedef struct emxArray_real_T emxArray_real_T;

#endif                                 /*typedef_emxArray_real_T*/

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

/* Function Declarations */
extern void getLaws(emxArray_real_T *image, emxArray_real_T *features);
extern void getLaws_api(const mxArray * const prhs[1], const mxArray *plhs[1]);
extern void getLaws_atexit(void);
extern void getLaws_initialize(void);
extern void getLaws_terminate(void);
extern void getLaws_xil_terminate(void);

#endif

/*
 * File trailer for _coder_getLaws_api.h
 *
 * [EOF]
 */
