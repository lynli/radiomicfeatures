/* 
 * Academic Student License -- for use by students to meet course 
 * requirements and perform academic research at degree granting 
 * institutions only.  Not for government, commercial, or other 
 * organizational use. 
 * File: _coder_getLaws_info.h 
 *  
 * MATLAB Coder version            : 3.3 
 * C/C++ source code generated on  : 05-Oct-2017 01:25:03 
 */

#ifndef _CODER_GETLAWS_INFO_H
#define _CODER_GETLAWS_INFO_H
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo();
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties();

#endif
/* 
 * File trailer for _coder_getLaws_info.h 
 *  
 * [EOF] 
 */
