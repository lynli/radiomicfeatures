//
// Academic Student License -- for use by students to meet course
// requirements and perform academic research at degree granting
// institutions only.  Not for government, commercial, or other
// organizational use.
// File: getLaws_initialize.cpp
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 05-Oct-2017 01:25:03
//

// Include Files
#include "rt_nonfinite.h"
#include "getLaws.h"
#include "getLaws_initialize.h"

// Function Definitions

//
// Arguments    : void
// Return Type  : void
//
void getLaws_initialize()
{
  rt_InitInfAndNaN(8U);
}

//
// File trailer for getLaws_initialize.cpp
//
// [EOF]
//
