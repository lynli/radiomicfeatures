//
// Academic Student License -- for use by students to meet course
// requirements and perform academic research at degree granting
// institutions only.  Not for government, commercial, or other
// organizational use.
// File: xnrm2.h
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 05-Oct-2017 01:25:03
//
#ifndef XNRM2_H
#define XNRM2_H

// Include Files
#include <cmath>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "getLaws_types.h"

// Function Declarations
extern double b_xnrm2(int n, const double x[5], int ix0);
extern double xnrm2(int n, const double x[25], int ix0);

#endif

//
// File trailer for xnrm2.h
//
// [EOF]
//
