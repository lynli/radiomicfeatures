//
// Academic Student License -- for use by students to meet course
// requirements and perform academic research at degree granting
// institutions only.  Not for government, commercial, or other
// organizational use.
// File: rot90.h
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 05-Oct-2017 01:25:03
//
#ifndef ROT90_H
#define ROT90_H

// Include Files
#include <cmath>
#include <math.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include "rt_nonfinite.h"
#include "rtwtypes.h"
#include "getLaws_types.h"

// Function Declarations
extern void rot90(const double A[25], double B[25]);

#endif

//
// File trailer for rot90.h
//
// [EOF]
//
