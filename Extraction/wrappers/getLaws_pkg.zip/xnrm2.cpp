//
// Academic Student License -- for use by students to meet course
// requirements and perform academic research at degree granting
// institutions only.  Not for government, commercial, or other
// organizational use.
// File: xnrm2.cpp
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 05-Oct-2017 01:25:03
//

// Include Files
#include "rt_nonfinite.h"
#include "getLaws.h"
#include "xnrm2.h"

// Function Definitions

//
// Arguments    : int n
//                const double x[5]
//                int ix0
// Return Type  : double
//
double b_xnrm2(int n, const double x[5], int ix0)
{
  double y;
  double scale;
  int kend;
  int k;
  double absxk;
  double t;
  y = 0.0;
  scale = 2.2250738585072014E-308;
  kend = (ix0 + n) - 1;
  for (k = ix0; k <= kend; k++) {
    absxk = std::abs(x[k - 1]);
    if (absxk > scale) {
      t = scale / absxk;
      y = 1.0 + y * t * t;
      scale = absxk;
    } else {
      t = absxk / scale;
      y += t * t;
    }
  }

  return scale * std::sqrt(y);
}

//
// Arguments    : int n
//                const double x[25]
//                int ix0
// Return Type  : double
//
double xnrm2(int n, const double x[25], int ix0)
{
  double y;
  double scale;
  int kend;
  int k;
  double absxk;
  double t;
  y = 0.0;
  scale = 2.2250738585072014E-308;
  kend = (ix0 + n) - 1;
  for (k = ix0; k <= kend; k++) {
    absxk = std::abs(x[k - 1]);
    if (absxk > scale) {
      t = scale / absxk;
      y = 1.0 + y * t * t;
      scale = absxk;
    } else {
      t = absxk / scale;
      y += t * t;
    }
  }

  return scale * std::sqrt(y);
}

//
// File trailer for xnrm2.cpp
//
// [EOF]
//
