//
// Academic Student License -- for use by students to meet course
// requirements and perform academic research at degree granting
// institutions only.  Not for government, commercial, or other
// organizational use.
// File: getLaws.cpp
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 05-Oct-2017 01:25:03
//

// Include Files
#include "rt_nonfinite.h"
#include "getLaws.h"
#include "rescale.h"
#include "getLaws_emxutil.h"
#include "xaxpy.h"
#include "eps.h"
#include "svd.h"
#include "rot90.h"

// Function Declarations
static void __anon_fcn(const emxArray_real_T *X, const double h[25],
  emxArray_real_T *varargout_1);
static double rt_roundd_snf(double u);

// Function Definitions

//
// Arguments    : const emxArray_real_T *X
//                const double h[25]
//                emxArray_real_T *varargout_1
// Return Type  : void
//
static void __anon_fcn(const emxArray_real_T *X, const double h[25],
  emxArray_real_T *varargout_1)
{
  double stencil[25];
  emxArray_real_T *work;
  boolean_T guard1 = false;
  boolean_T trysepp;
  int k;
  boolean_T exitg1;
  int rank;
  double u[25];
  double s[25];
  double v[25];
  int cidx;
  double tol;
  int X_idx_1;
  int X_idx_0;
  int ma;
  int na;
  int iC;
  double hcol[5];
  int iA;
  double hrow[5];
  int firstColB;
  int lastColB;
  int firstRowB;
  int lastRowB;
  int lastColA;
  int exitg3;
  int b_firstColB;
  int iB;
  int i;
  int jmkom1;
  int exitg2;
  int b_i;
  int a_length;
  rot90(h, stencil);
  emxInit_real_T(&work, 2);
  guard1 = false;
  if (25 <= X->size[0] * X->size[1]) {
    trysepp = true;
    k = 0;
    exitg1 = false;
    while ((!exitg1) && (k < 25)) {
      if (!((!rtIsInf(stencil[k])) && (!rtIsNaN(stencil[k])))) {
        trysepp = false;
        exitg1 = true;
      } else {
        k++;
      }
    }

    if (trysepp) {
      svd(stencil, u, s, v);
      tol = 5.0 * eps(s[24]);
      rank = 0;
      for (k = 0; k < 5; k++) {
        if (s[k + 5 * k] > tol) {
          rank++;
        }
      }

      if (rank == 1) {
        tol = std::sqrt(s[0]);
        for (rank = 0; rank < 5; rank++) {
          hcol[rank] = u[rank] * tol;
          hrow[rank] = v[rank] * tol;
        }

        iC = X->size[0];
        iA = X->size[1];
        rank = X->size[0] * X->size[1];
        trysepp = false;
        for (k = 0; k + 1 <= rank; k++) {
          if (trysepp || rtIsInf(X->data[k]) || rtIsNaN(X->data[k])) {
            trysepp = true;
          } else {
            trysepp = false;
          }
        }

        rank = work->size[0] * work->size[1];
        work->size[0] = X->size[0];
        work->size[1] = X->size[1];
        emxEnsureCapacity((emxArray__common *)work, rank, sizeof(double));
        cidx = X->size[0] * X->size[1];
        for (rank = 0; rank < cidx; rank++) {
          work->data[rank] = 0.0;
        }

        rank = varargout_1->size[0] * varargout_1->size[1];
        varargout_1->size[0] = X->size[0];
        varargout_1->size[1] = X->size[1];
        emxEnsureCapacity((emxArray__common *)varargout_1, rank, sizeof(double));
        cidx = X->size[0] * X->size[1];
        for (rank = 0; rank < cidx; rank++) {
          varargout_1->data[rank] = 0.0;
        }

        if ((X->size[0] == 0) || (X->size[1] == 0)) {
        } else {
          if (4 - X->size[0] < 1) {
            k = -1;
          } else {
            k = 2 - X->size[0];
          }

          lastColA = X->size[0] + 2;
          if (5 < lastColA) {
            lastColA = 5;
          }

          while (k + 2 <= lastColA) {
            if (k > 0) {
              cidx = k;
            } else {
              cidx = 1;
            }

            jmkom1 = (iC + k) - 1;
            if (jmkom1 > iC) {
              jmkom1 = iC;
            }

            rank = (jmkom1 - cidx) + 1;
            if ((hcol[k + 1] == 0.0) && trysepp) {
              for (lastRowB = 0; lastRowB + 1 <= iA; lastRowB++) {
                for (i = cidx; i <= jmkom1; i++) {
                  work->data[(i + work->size[0] * lastRowB) - 1] += X->data[(i -
                    k) + X->size[0] * lastRowB] * 0.0;
                }
              }
            } else {
              for (lastRowB = 0; lastRowB + 1 <= iA; lastRowB++) {
                d_xaxpy(rank, hcol[k + 1], X, ((lastRowB * iC + cidx) - k) + 1,
                        work, lastRowB * iC + cidx);
              }
            }

            k++;
          }

          if (4 - X->size[1] < 1) {
            k = -1;
          } else {
            k = 2 - X->size[1];
          }

          lastColA = X->size[1] + 2;
          if (5 < lastColA) {
            lastColA = 5;
          }

          while (k + 2 <= lastColA) {
            if (k > 0) {
              rank = k - 1;
            } else {
              rank = 0;
            }

            cidx = (iA + k) - 1;
            if (cidx > iA) {
              cidx = iA;
            }

            if ((hrow[k + 1] == 0.0) && trysepp) {
              while (rank + 1 <= cidx) {
                jmkom1 = (rank - k) + 1;
                for (i = 0; i + 1 <= iC; i++) {
                  varargout_1->data[i + varargout_1->size[0] * rank] +=
                    work->data[i + work->size[0] * jmkom1] * 0.0;
                }

                rank++;
              }
            } else {
              d_xaxpy(iC * (cidx - rank), hrow[k + 1], work, ((rank - k) + 1) *
                      iC + 1, varargout_1, rank * iC + 1);
            }

            k++;
          }
        }

        k = 0;
        do {
          exitg3 = 0;
          if (k < 25) {
            if (std::floor(stencil[k]) != stencil[k]) {
              exitg3 = 1;
            } else {
              k++;
            }
          } else {
            k = 0;
            exitg3 = 2;
          }
        } while (exitg3 == 0);

        if (exitg3 == 1) {
        } else {
          do {
            exitg2 = 0;
            if (k <= X->size[0] * X->size[1] - 1) {
              if (std::floor(X->data[k]) != X->data[k]) {
                exitg2 = 1;
              } else {
                k++;
              }
            } else {
              rank = varargout_1->size[0] * varargout_1->size[1];
              for (k = 0; k + 1 <= rank; k++) {
                varargout_1->data[k] = rt_roundd_snf(varargout_1->data[k]);
              }

              exitg2 = 1;
            }
          } while (exitg2 == 0);
        }
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }
  } else {
    guard1 = true;
  }

  if (guard1) {
    rank = varargout_1->size[0] * varargout_1->size[1];
    varargout_1->size[0] = X->size[0];
    varargout_1->size[1] = X->size[1];
    emxEnsureCapacity((emxArray__common *)varargout_1, rank, sizeof(double));
    cidx = X->size[0] * X->size[1];
    for (rank = 0; rank < cidx; rank++) {
      varargout_1->data[rank] = 0.0;
    }

    trysepp = ((X->size[0] == 0) || (X->size[1] == 0));
    if (!trysepp) {
      X_idx_1 = X->size[1];
      X_idx_0 = X->size[0];
      ma = X->size[0];
      na = X->size[1] - 1;
      if (X->size[1] < 2) {
        firstColB = 3 - X->size[1];
      } else {
        firstColB = 0;
      }

      rank = X->size[1];
      if (5 <= rank + 1) {
        lastColB = 4;
      } else {
        rank = X->size[1];
        lastColB = rank + 1;
      }

      if (X->size[0] < 2) {
        firstRowB = 3 - X->size[0];
      } else {
        firstRowB = 0;
      }

      rank = X->size[0];
      if (5 <= rank + 1) {
        lastRowB = 4;
      } else {
        rank = X->size[0];
        lastRowB = rank + 1;
      }

      while (firstColB <= lastColB) {
        if (firstColB + na < X_idx_1 + 1) {
          lastColA = na;
        } else {
          lastColA = (X_idx_1 - firstColB) + 1;
        }

        if (firstColB < 2) {
          k = 2 - firstColB;
        } else {
          k = 0;
        }

        while (k <= lastColA) {
          if (firstColB + k > 2) {
            b_firstColB = (firstColB + k) - 2;
          } else {
            b_firstColB = 0;
          }

          iC = b_firstColB * X_idx_0;
          iA = k * ma;
          iB = firstRowB + firstColB * 5;
          for (i = firstRowB; i <= lastRowB; i++) {
            if (i < 2) {
              rank = 2 - i;
            } else {
              rank = 0;
            }

            if (i + ma <= X_idx_0 + 1) {
              b_i = ma;
            } else {
              b_i = (X_idx_0 - i) + 2;
            }

            a_length = b_i - rank;
            rank += iA;
            cidx = iC;
            for (jmkom1 = 1; jmkom1 <= a_length; jmkom1++) {
              varargout_1->data[cidx] += stencil[iB] * X->data[rank];
              rank++;
              cidx++;
            }

            iB++;
            if (i >= 2) {
              iC++;
            }
          }

          k++;
        }

        firstColB++;
      }
    }
  }

  emxFree_real_T(&work);
}

//
// Arguments    : double u
// Return Type  : double
//
static double rt_roundd_snf(double u)
{
  double y;
  if (std::abs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = std::floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = std::ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

//
// a good statistical measure of randomness
// Arguments    : const emxArray_real_T *image
//                emxArray_real_T *features
// Return Type  : void
//
void getLaws(const emxArray_real_T *image, emxArray_real_T *features)
{
  unsigned int unnamed_idx_0;
  unsigned int unnamed_idx_1;
  int i0;
  int loop_ub;
  emxArray_real_T *r0;
  emxArray_real_T *r1;
  int i;
  double KK[25];
  int i1;
  static const signed char b_KK[625] = { 1, 4, 6, 4, 1, 4, 16, 24, 16, 4, 6, 24,
    36, 24, 6, 4, 16, 24, 16, 4, 1, 4, 6, 4, 1, -1, -4, -6, -4, -1, -2, -8, -12,
    -8, -2, 0, 0, 0, 0, 0, 2, 8, 12, 8, 2, 1, 4, 6, 4, 1, -1, -4, -6, -4, -1, 0,
    0, 0, 0, 0, 2, 8, 12, 8, 2, 0, 0, 0, 0, 0, -1, -4, -6, -4, -1, -1, -4, -6,
    -4, -1, 2, 8, 12, 8, 2, 0, 0, 0, 0, 0, -2, -8, -12, -8, -2, 1, 4, 6, 4, 1, 1,
    4, 6, 4, 1, -4, -16, -24, -16, -4, 6, 24, 36, 24, 6, -4, -16, -24, -16, -4,
    1, 4, 6, 4, 1, -1, -2, 0, 2, 1, -4, -8, 0, 8, 4, -6, -12, 0, 12, 6, -4, -8,
    0, 8, 4, -1, -2, 0, 2, 1, 1, 2, 0, -2, -1, 2, 4, 0, -4, -2, 0, 0, 0, 0, 0,
    -2, -4, 0, 4, 2, -1, -2, 0, 2, 1, 1, 2, 0, -2, -1, 0, 0, 0, 0, 0, -2, -4, 0,
    4, 2, 0, 0, 0, 0, 0, 1, 2, 0, -2, -1, 1, 2, 0, -2, -1, -2, -4, 0, 4, 2, 0, 0,
    0, 0, 0, 2, 4, 0, -4, -2, -1, -2, 0, 2, 1, -1, -2, 0, 2, 1, 4, 8, 0, -8, -4,
    -6, -12, 0, 12, 6, 4, 8, 0, -8, -4, -1, -2, 0, 2, 1, -1, 0, 2, 0, -1, -4, 0,
    8, 0, -4, -6, 0, 12, 0, -6, -4, 0, 8, 0, -4, -1, 0, 2, 0, -1, 1, 0, -2, 0, 1,
    2, 0, -4, 0, 2, 0, 0, 0, 0, 0, -2, 0, 4, 0, -2, -1, 0, 2, 0, -1, 1, 0, -2, 0,
    1, 0, 0, 0, 0, 0, -2, 0, 4, 0, -2, 0, 0, 0, 0, 0, 1, 0, -2, 0, 1, 1, 0, -2,
    0, 1, -2, 0, 4, 0, -2, 0, 0, 0, 0, 0, 2, 0, -4, 0, 2, -1, 0, 2, 0, -1, -1, 0,
    2, 0, -1, 4, 0, -8, 0, 4, -6, 0, 12, 0, -6, 4, 0, -8, 0, 4, -1, 0, 2, 0, -1,
    -1, 2, 0, -2, 1, -4, 8, 0, -8, 4, -6, 12, 0, -12, 6, -4, 8, 0, -8, 4, -1, 2,
    0, -2, 1, 1, -2, 0, 2, -1, 2, -4, 0, 4, -2, 0, 0, 0, 0, 0, -2, 4, 0, -4, 2,
    -1, 2, 0, -2, 1, 1, -2, 0, 2, -1, 0, 0, 0, 0, 0, -2, 4, 0, -4, 2, 0, 0, 0, 0,
    0, 1, -2, 0, 2, -1, 1, -2, 0, 2, -1, -2, 4, 0, -4, 2, 0, 0, 0, 0, 0, 2, -4,
    0, 4, -2, -1, 2, 0, -2, 1, -1, 2, 0, -2, 1, 4, -8, 0, 8, -4, -6, 12, 0, -12,
    6, 4, -8, 0, 8, -4, -1, 2, 0, -2, 1, 1, -4, 6, -4, 1, 4, -16, 24, -16, 4, 6,
    -24, 36, -24, 6, 4, -16, 24, -16, 4, 1, -4, 6, -4, 1, -1, 4, -6, 4, -1, -2,
    8, -12, 8, -2, 0, 0, 0, 0, 0, 2, -8, 12, -8, 2, 1, -4, 6, -4, 1, -1, 4, -6,
    4, -1, 0, 0, 0, 0, 0, 2, -8, 12, -8, 2, 0, 0, 0, 0, 0, -1, 4, -6, 4, -1, -1,
    4, -6, 4, -1, 2, -8, 12, -8, 2, 0, 0, 0, 0, 0, -2, 8, -12, 8, -2, 1, -4, 6,
    -4, 1, 1, -4, 6, -4, 1, -4, 16, -24, 16, -4, 6, -24, 36, -24, 6, -4, 16, -24,
    16, -4, 1, -4, 6, -4, 1 };

  int b_loop_ub;

  //  radius of kernel window
  //  LAWSFILTER Apply 2D Law's filters to an image.
  //
  //    LAWSRESPONSES = LAWSFILTER(I) returns in LAWSRESPONSES a N-by-M-by-25
  //        array containing the 25 filter responses from the laws kernels.
  //
  //    See also: lawskerns, imfilter.
  //
  // JCC
  //  If imfilter is available, use it, otherwise use filter2
  // if exist('imfilter','file'),
  //     filterfun=@(X,h) imfilter(X,h);
  // else
  // end
  //  Calculate filter responses
  unnamed_idx_0 = (unsigned int)image->size[0];
  unnamed_idx_1 = (unsigned int)image->size[1];
  i0 = features->size[0] * features->size[1] * features->size[2];
  features->size[0] = (int)unnamed_idx_0;
  features->size[1] = (int)unnamed_idx_1;
  features->size[2] = 25;
  emxEnsureCapacity((emxArray__common *)features, i0, sizeof(double));
  loop_ub = (int)unnamed_idx_0 * (int)unnamed_idx_1 * 25;
  for (i0 = 0; i0 < loop_ub; i0++) {
    features->data[i0] = 0.0;
  }

  emxInit_real_T(&r0, 2);
  emxInit_real_T(&r1, 2);
  for (i = 0; i < 25; i++) {
    for (i0 = 0; i0 < 5; i0++) {
      for (i1 = 0; i1 < 5; i1++) {
        KK[i1 + 5 * i0] = b_KK[(i1 + 5 * i0) + 25 * i];
      }
    }

    __anon_fcn(image, KK, r1);
    loop_ub = r1->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = r1->size[0];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        features->data[(i1 + features->size[0] * i0) + features->size[0] *
          features->size[1] * i] = r1->data[i1 + r1->size[0] * i0];
      }
    }

    loop_ub = features->size[0];
    b_loop_ub = features->size[1];
    i0 = r0->size[0] * r0->size[1];
    r0->size[0] = loop_ub;
    r0->size[1] = b_loop_ub;
    emxEnsureCapacity((emxArray__common *)r0, i0, sizeof(double));
    for (i0 = 0; i0 < b_loop_ub; i0++) {
      for (i1 = 0; i1 < loop_ub; i1++) {
        r0->data[i1 + r0->size[0] * i0] = features->data[(i1 + features->size[0]
          * i0) + features->size[0] * features->size[1] * i];
      }
    }

    rescale(r0);
    loop_ub = r0->size[1];
    for (i0 = 0; i0 < loop_ub; i0++) {
      b_loop_ub = r0->size[0];
      for (i1 = 0; i1 < b_loop_ub; i1++) {
        features->data[(i1 + features->size[0] * i0) + features->size[0] *
          features->size[1] * i] = r0->data[i1 + r0->size[0] * i0];
      }
    }
  }

  emxFree_real_T(&r1);
  emxFree_real_T(&r0);
}

//
// File trailer for getLaws.cpp
//
// [EOF]
//
