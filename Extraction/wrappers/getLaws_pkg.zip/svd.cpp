//
// Academic Student License -- for use by students to meet course
// requirements and perform academic research at degree granting
// institutions only.  Not for government, commercial, or other
// organizational use.
// File: svd.cpp
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 05-Oct-2017 01:25:03
//

// Include Files
#include "rt_nonfinite.h"
#include "getLaws.h"
#include "svd.h"
#include "svd1.h"

// Function Definitions

//
// Arguments    : const double A[25]
//                double U[25]
//                double S[25]
//                double V[25]
// Return Type  : void
//
void svd(const double A[25], double U[25], double S[25], double V[25])
{
  double s[5];
  int k;
  b_svd(A, U, s, V);
  memset(&S[0], 0, 25U * sizeof(double));
  for (k = 0; k < 5; k++) {
    S[k + 5 * k] = s[k];
  }
}

//
// File trailer for svd.cpp
//
// [EOF]
//
