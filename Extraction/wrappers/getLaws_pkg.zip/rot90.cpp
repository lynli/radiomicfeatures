//
// Academic Student License -- for use by students to meet course
// requirements and perform academic research at degree granting
// institutions only.  Not for government, commercial, or other
// organizational use.
// File: rot90.cpp
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 05-Oct-2017 01:25:03
//

// Include Files
#include "rt_nonfinite.h"
#include "getLaws.h"
#include "rot90.h"

// Function Definitions

//
// Arguments    : const double A[25]
//                double B[25]
// Return Type  : void
//
void rot90(const double A[25], double B[25])
{
  int j;
  int i;
  for (j = 0; j < 5; j++) {
    for (i = 0; i < 5; i++) {
      B[i + 5 * j] = A[(5 * (4 - j) - i) + 4];
    }
  }
}

//
// File trailer for rot90.cpp
//
// [EOF]
//
