//
// Academic Student License -- for use by students to meet course
// requirements and perform academic research at degree granting
// institutions only.  Not for government, commercial, or other
// organizational use.
// File: xswap.cpp
//
// MATLAB Coder version            : 3.3
// C/C++ source code generated on  : 05-Oct-2017 01:25:03
//

// Include Files
#include "rt_nonfinite.h"
#include "getLaws.h"
#include "xswap.h"

// Function Definitions

//
// Arguments    : double x[25]
//                int ix0
//                int iy0
// Return Type  : void
//
void xswap(double x[25], int ix0, int iy0)
{
  int ix;
  int iy;
  int k;
  double temp;
  ix = ix0 - 1;
  iy = iy0 - 1;
  for (k = 0; k < 5; k++) {
    temp = x[ix];
    x[ix] = x[iy];
    x[iy] = temp;
    ix++;
    iy++;
  }
}

//
// File trailer for xswap.cpp
//
// [EOF]
//
