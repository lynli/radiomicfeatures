/*
 * Academic Student License -- for use by students to meet course
 * requirements and perform academic research at degree granting
 * institutions only.  Not for government, commercial, or other
 * organizational use.
 * File: rtGetNaN.h
 *
 * MATLAB Coder version            : 3.3
 * C/C++ source code generated on  : 05-Oct-2017 01:25:03
 */

#ifndef RTGETNAN_H
#define RTGETNAN_H
#include <stddef.h>
#include "rtwtypes.h"
#include "rt_nonfinite.h"

extern real_T rtGetNaN(void);
extern real32_T rtGetNaNF(void);

#endif

/*
 * File trailer for rtGetNaN.h
 *
 * [EOF]
 */
